#!/bin/bash

echo $* - prints all numbers from 1 to 25
echo $@ - prints all numbers in array style
echo $# - total number of arguments
echo $- - current option flag
echo $$ - PID of the shell
echo $! - PID of last executed BG command
echo $0 - script name 
echo $_ - final argument of last executed foreground command
echo $? - exit code of last command
