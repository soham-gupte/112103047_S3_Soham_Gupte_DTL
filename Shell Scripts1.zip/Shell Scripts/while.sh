#!/bin/bash

count=0

while [ $count -lt 10 ]; do
	echo $count
        let count+=1
done	
