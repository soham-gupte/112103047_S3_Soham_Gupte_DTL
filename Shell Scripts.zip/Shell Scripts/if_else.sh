#!/bin/bash

name="Soham"

if [ $name = "Soham" ];
then
	echo Welcome back $name;
else
	echo Sorry, wrong username!;
fi	
