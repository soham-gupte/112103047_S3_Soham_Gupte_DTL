#!/bin/bash

count=4
for ((a=0;a<count;a++));do
	for ((b=0;b<count;b++));do
		echo $a $b
done
done
