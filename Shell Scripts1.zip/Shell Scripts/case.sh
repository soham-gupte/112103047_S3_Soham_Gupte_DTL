#!/bin/bash

echo Enter the number:
read a

case $a in 
	1)
		echo "Hello"
		;;
	2)
		echo "Bye"
		;;
	3)
		echo "Bonjour"
		;;
	*) 
		echo Default
		;;
esac

