#!/bin/bash

echo Enter the number:
read a

if [ $a = 1 ]; then
	echo Hello, 1
elif [ $a = 2 ]; then
	echo Hello, 2
else
	echo Not valid!
fi
